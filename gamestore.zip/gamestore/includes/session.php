<?php
// includes/session.php

session_start();

// Gerar ID de sessão se não existir
if (!isset($_SESSION['session_id'])) {
    $_SESSION['session_id'] = session_id();
}

function getSessionId() {
    return $_SESSION['session_id'];
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

function isAdmin() {
    return $_SESSION['is_admin'] ?? false;
}