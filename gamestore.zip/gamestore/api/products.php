<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
// api/products.php

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        // Listar produtos
        $category_id = $_GET['category'] ?? null;
        $search = $_GET['search'] ?? null;
        $sort = $_GET['sort'] ?? 'featured';
        
        $query = "SELECT p.*, c.name as category_name 
                  FROM products p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.is_active = 1";
        
        $params = [];
        
        if ($category_id && $category_id != 'all') {
            $query .= " AND p.category_id = :category_id";
            $params[':category_id'] = $category_id;
        }
        
        if ($search) {
            $query .= " AND (p.name LIKE :search OR p.description LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        // Ordenação
        switch($sort) {
            case 'price-low':
                $query .= " ORDER BY p.price ASC";
                break;
            case 'price-high':
                $query .= " ORDER BY p.price DESC";
                break;
            case 'name':
                $query .= " ORDER BY p.name ASC";
                break;
            default:
                $query .= " ORDER BY p.id DESC";
        }
        
        $stmt = $db->prepare($query);
        
        foreach($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $products
        ]);
        break;
        
    case 'POST':
        // Criar produto (admin apenas)
        if (!isAdmin()) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Acesso negado']);
            exit;
        }
        
        $data = json_decode(file_get_contents("php://input"), true);
        
        $query = "INSERT INTO products (name, description, price, category_id, stock, image_url) 
                  VALUES (:name, :description, :price, :category_id, :stock, :image_url)";
        
        $stmt = $db->prepare($query);
        
        $stmt->bindValue(':name', $data['name']);
        $stmt->bindValue(':description', $data['description']);
        $stmt->bindValue(':price', $data['price']);
        $stmt->bindValue(':category_id', $data['category_id']);
        $stmt->bindValue(':stock', $data['stock']);
        $stmt->bindValue(':image_url', $data['image_url']);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'id' => $db->lastInsertId(),
                'message' => 'Produto criado com sucesso'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao criar produto']);
        }
        break;
}