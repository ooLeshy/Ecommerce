<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
// api/cart.php

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$session_id = getSessionId();

switch($method) {
    case 'GET':
        // Obter itens do carrinho
        $query = "SELECT ci.*, p.name, p.price, p.image_url, p.stock 
                  FROM cart_items ci 
                  JOIN products p ON ci.product_id = p.id 
                  WHERE ci.session_id = :session_id";
        
        $stmt = $db->prepare($query);
        $stmt->bindValue(':session_id', $session_id);
        $stmt->execute();
        
        $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calcular totais
        $subtotal = 0;
        foreach($cart_items as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }
        
        $shipping = $subtotal > 200 ? 0 : 15;
        $total = $subtotal + $shipping;
        
        echo json_encode([
            'success' => true,
            'items' => $cart_items,
            'summary' => [
                'subtotal' => $subtotal,
                'shipping' => $shipping,
                'total' => $total
            ]
        ]);
        break;
        
    case 'POST':
        // Adicionar item ao carrinho
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Verificar se o produto já está no carrinho
        $query = "SELECT * FROM cart_items 
                  WHERE session_id = :session_id AND product_id = :product_id";
        
        $stmt = $db->prepare($query);
        $stmt->bindValue(':session_id', $session_id);
        $stmt->bindValue(':product_id', $data['product_id']);
        $stmt->execute();
        
        $existing_item = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing_item) {
            // Atualizar quantidade
            $new_quantity = $existing_item['quantity'] + ($data['quantity'] ?? 1);
            
            $query = "UPDATE cart_items SET quantity = :quantity 
                      WHERE id = :id";
            
            $stmt = $db->prepare($query);
            $stmt->bindValue(':quantity', $new_quantity);
            $stmt->bindValue(':id', $existing_item['id']);
        } else {
            // Inserir novo item
            $query = "INSERT INTO cart_items (session_id, product_id, quantity) 
                      VALUES (:session_id, :product_id, :quantity)";
            
            $stmt = $db->prepare($query);
            $stmt->bindValue(':session_id', $session_id);
            $stmt->bindValue(':product_id', $data['product_id']);
            $stmt->bindValue(':quantity', $data['quantity'] ?? 1);
        }
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Item adicionado ao carrinho'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao adicionar item']);
        }
        break;
        
    case 'DELETE':
        // Remover item do carrinho
        $product_id = $_GET['product_id'] ?? null;
        
        if (!$product_id) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID do produto não especificado']);
            exit;
        }
        
        $query = "DELETE FROM cart_items 
                  WHERE session_id = :session_id AND product_id = :product_id";
        
        $stmt = $db->prepare($query);
        $stmt->bindValue(':session_id', $session_id);
        $stmt->bindValue(':product_id', $product_id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Item removido do carrinho'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao remover item']);
        }
        break;
        
    case 'PUT':
        // Atualizar quantidade
        $data = json_decode(file_get_contents("php://input"), true);
        
        $query = "UPDATE cart_items SET quantity = :quantity 
                  WHERE session_id = :session_id AND product_id = :product_id";
        
        $stmt = $db->prepare($query);
        $stmt->bindValue(':quantity', $data['quantity']);
        $stmt->bindValue(':session_id', $session_id);
        $stmt->bindValue(':product_id', $data['product_id']);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Quantidade atualizada'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao atualizar quantidade']);
        }
        break;
}