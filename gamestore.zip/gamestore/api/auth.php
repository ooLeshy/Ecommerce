<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
// api/auth.php

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $action = $data['action'] ?? '';
        
        if ($action === 'login') {
            // Login
            $query = "SELECT id, name, email, password_hash, is_admin 
                      FROM users WHERE email = :email";
            
            $stmt = $db->prepare($query);
            $stmt->bindValue(':email', $data['email']);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($data['password'], $user['password_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['is_admin'] = $user['is_admin'];
                
                echo json_encode([
                    'success' => true,
                    'user' => [
                        'id' => $user['id'],
                        'name' => $user['name'],
                        'email' => $user['email'],
                        'is_admin' => $user['is_admin']
                    ]
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Credenciais inválidas'
                ]);
            }
            
        } elseif ($action === 'register') {
            // Registro
            // Verificar se email já existe
            $query = "SELECT id FROM users WHERE email = :email";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':email', $data['email']);
            $stmt->execute();
            
            if ($stmt->fetch()) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Email já cadastrado'
                ]);
                exit;
            }
            
            // Criar novo usuário
            $query = "INSERT INTO users (name, email, password_hash) 
                      VALUES (:name, :email, :password_hash)";
            
            $stmt = $db->prepare($query);
            
            $stmt->bindValue(':name', $data['name']);
            $stmt->bindValue(':email', $data['email']);
            $stmt->bindValue(':password_hash', password_hash($data['password'], PASSWORD_DEFAULT));
            
            if ($stmt->execute()) {
                $user_id = $db->lastInsertId();
                
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $data['name'];
                $_SESSION['user_email'] = $data['email'];
                $_SESSION['is_admin'] = false;
                
                echo json_encode([
                    'success' => true,
                    'user' => [
                        'id' => $user_id,
                        'name' => $data['name'],
                        'email' => $data['email'],
                        'is_admin' => false
                    ]
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Erro ao criar conta'
                ]);
            }
        }
        break;
        
    case 'GET':
        // Verificar se usuário está logado
        if (isLoggedIn()) {
            echo json_encode([
                'success' => true,
                'user' => [
                    'id' => $_SESSION['user_id'],
                    'name' => $_SESSION['user_name'],
                    'email' => $_SESSION['user_email'],
                    'is_admin' => $_SESSION['is_admin']
                ]
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Não autenticado'
            ]);
        }
        break;
        
    case 'DELETE':
        // Logout
        session_destroy();
        echo json_encode([
            'success' => true,
            'message' => 'Logout realizado'
        ]);
        break;
}